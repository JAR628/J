import AddApp.*;

public class AddImpl extends AddPOA {
  public float add(float a, float b) {
    return a + b;
  }
}
