import AddApp.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;

public class AddClient {
  public static void main(String[] args) throws Exception {
    ORB orb = ORB.init(args, null);
    NamingContextExt ncRef = NamingContextExtHelper.narrow(
      orb.resolve_initial_references("NameService"));

    Add addRef = AddHelper.narrow(ncRef.resolve_str("Add"));
    System.out.println("Result: " + addRef.add(10, 20));
  }
}
