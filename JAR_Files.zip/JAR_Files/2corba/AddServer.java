import AddApp.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.CosNaming.*;

public class AddServer {
  public static void main(String[] args) throws Exception {
    ORB orb = ORB.init(args, null);
    POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
    rootPOA.the_POAManager().activate();

    AddImpl addObj = new AddImpl();
    org.omg.CORBA.Object ref = rootPOA.servant_to_reference(addObj);
    Add href = AddHelper.narrow(ref);

    NamingContextExt ncRef = NamingContextExtHelper.narrow(
      orb.resolve_initial_references("NameService"));
    ncRef.rebind(ncRef.to_name("Add"), href);

    System.out.println("AddServer ready...");
    orb.run();
  }
}
